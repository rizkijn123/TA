<!DOCTYPE html>
<html>

<head>
    <title>403 Forbidden</title>
</head>

<body>

    <p>Directory access is forbidden.</p>
    <a href="<?= base_url('user/profile') ?>">Back to Dashboard</a>
</body>

</html>