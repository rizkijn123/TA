   <!-- beranda -->
   <section id="beranda">
       <div class="container">
           <div class="row">
               <div class="col">
                   <h2 class="text-center">Beranda</h2>
               </div>
           </div>
           <div class="row ">
               <div class="col">
                   <div style="padding:10px">
                       <center>
                           latitude = <span id="lat"></span><br>
                           longitude = <span id="long"></span><br>
                           pesan = <span id="pesan"></span><br><br>
                           <div id="map"></div>
                       </center>
                   </div>
               </div>
           </div>
       </div>
   </section>
   <!-- end beranda -->