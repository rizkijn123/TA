<section id="footer">
    <div class="container text-light">
        <div class="row">
            <div class="col pt-2">
                <h2 class="text-center">Contact Us</h2>
            </div>
        </div>
        <div class="row justify-content-evenly">
            <div class="col-md-4 pt-5">
                Rizki Jaelani Nugraha<br>
                Muhammad Ridwansyah<br>
                Nur Rizki
            </div>
            <div class="col-md-4 pt-5">
            </div>
        </div>
    </div>
</section>
<!-- end beranda -->
<!-- footer -->
<footer class="text-center text-light">Proposal Tugas Akhir</footer>
<!-- end footer -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous">
</script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBPgLoFxMM4DEbbg6YCV54f4zH8d1bngsQ&callback=initMap">
</script>
</body>

</html>