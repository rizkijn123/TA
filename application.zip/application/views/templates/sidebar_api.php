<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <style>
        #map {
            height: 300px;
            width: 600px;
        }
    </style>
    <link rel="apple-touch-icon" sizes="76x76" href="<?= base_url('assets/'); ?>img/apple-icon.png">
    <link rel="icon" type="image/png" href="#">
    <title>
        <?= $title ?>
    </title>
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet" />
    <!-- Nucleo Icons -->
    <link href="<?= base_url('assets/'); ?>css/nucleo-icons.css" rel="stylesheet" />
    <link href="<?= base_url('assets/'); ?>css/nucleo-svg.css" rel="stylesheet" />
    <!-- Font Awesome Icons -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>
    <link href="<?= base_url('assets/'); ?>css/nucleo-svg.css" rel="stylesheet" />
    <!-- CSS Files -->
    <link id="pagestyle" href="<?= base_url('assets/'); ?>css/soft-ui-dashboard.css?v=1.0.7" rel="stylesheet" />
    <script>
        var map;
        var x;
        var y;
        var marker = null;
        var m;
        var view;


        function initMap() {

            var myLatLng = {
                lat: -6.914864,
                lng: 107.608238
            };

            map = new google.maps.Map(document.getElementById('map'), {
                center: myLatLng,
                zoom: 14,
                mapTypeId: 'satellite'
            });

        }

        function loadmaps() {
            $.getJSON("<?= base_url('load/'); ?>api.php?devicename=<?= $user['deviceName']; ?>", function(
                result) {

                var m = result;
                x = Number(m[0].data.Lat);
                //alert(x);

            });
            $.getJSON("<?= base_url('load/'); ?>api.php?devicename=<?= $user['deviceName']; ?>", function(
                result) {

                var m = result;
                y = Number(m[0].data.Lon);
                view = Number(m[0].data.Btn);

            }).done(function() {
                document.getElementById("lat").innerHTML = x;
                document.getElementById("long").innerHTML = y;
                if (view == "1") {
                    document.getElementById("pesan").setAttribute('class', 'alert alert-danger text-white mx-3');
                    document.getElementById("pesan").innerHTML = "Button Active";
                } else {
                    document.getElementById("pesan").setAttribute('class', 'alert alert-success text-white mx-3');
                    document.getElementById("pesan").innerHTML = "Button Off";
                }
                initialize();
            });

        }
        window.setInterval(function() {
            loadmaps();
        }, 2000);

        function initialize() {
            //alert(y);
            var newPoint = new google.maps.LatLng(x, y);

            if (marker) {
                // Marker already created - Move it
                marker.setPosition(newPoint);
            } else {
                // Marker does not exist - Create it
                marker = new google.maps.Marker({
                    position: newPoint,
                    map: map
                });
            }

            // Center the map on the new position
            map.setCenter(newPoint);
            var infowindow = new google.maps.InfoWindow({
                content: '<p>Marker Location:' + marker.getPosition() + '</p>'
            });

            google.maps.event.addListener(marker, 'click', function() {
                infowindow.open(map, marker);
            });
        }

        google.maps.event.addDomListener(window, 'load', initialize);
    </script>
    <!-- <script>
        setInterval(function() {
            $("#lat").load("<?= base_url('load/'); ?>lat.php");
        }, 600);
        setInterval(function() {
            $("#long").load("<?= base_url('load/'); ?>long.php");
        }, 600);
        setInterval(function() {
            $("#pesan").load("<?= base_url('load/'); ?>test.php");
        }, 600);
    </script> -->
</head>

<body class="g-sidenav-show  bg-gray-100">
    <aside class="sidenav navbar navbar-vertical navbar-expand-xs border-0 border-radius-xl my-3 fixed-start ms-3 " id="sidenav-main">
        <div class="sidenav-header">
            <i class="fas fa-times p-3 cursor-pointer text-secondary opacity-5 position-absolute end-0 top-0 d-none d-xl-none" aria-hidden="true" id="iconSidenav"></i>
            <a class="navbar-brand m-0" href="#" target="_blank">
                <i class="fas fa-project-diagram"></i>
                <span class="ms-1 font-weight-bold"><?= $title ?></span>
            </a>
        </div>
        <hr class="horizontal dark mt-0">
        <div class="collapse navbar-collapse  w-auto " id="sidenav-collapse-main">
            <ul class="navbar-nav">
                <!-- Query menu -->
                <?php
                $role_id = $this->session->userdata('role_id');
                $queryMenu = "SELECT `user_menu`.`id`, `menu`
                                FROM `user_menu` JOIN `user_access_menu` 
                                ON `user_menu`.`id` = `user_access_menu`.`menu_id`
                                WHERE `user_access_menu`.`role_id` = $role_id
                                ORDER BY `user_access_menu`.`menu_id` ASC
                                ";
                $menu = $this->db->query($queryMenu)->result_array();
                ?>
                <!-- looping menu  -->
                <?php foreach ($menu as $m) : ?>
                    <li class="nav-item mt-3">
                        <h6 class="ps-4 ms-2 text-uppercase text-xs font-weight-bolder opacity-6"><?= $m['menu']; ?></h6>
                    </li>


                    <!-- submenu -->
                    <?php
                    $menuId = $m['id'];
                    $querySubmenu = "SELECT * FROM `user_sub_menu` 
                                WHERE `menu_id` = $menuId
                                AND `is_active` = 1";
                    $subMenu = $this->db->query($querySubmenu)->result_array();
                    ?>
                    <?php foreach ($subMenu as $sm) : ?>
                        <li class="nav-item">
                            <?php if ($page_title == $sm['title']) : ?>
                                <a class="nav-link active" href="<?= base_url($sm['url']) ?>">
                                <?php else : ?>
                                    <a class="nav-link" href="<?= base_url($sm['url']) ?>">
                                    <?php endif; ?>

                                    <div class="icon icon-shape icon-sm shadow border-radius-md bg-white text-center me-2 d-flex align-items-center justify-content-center">
                                        <?= $sm['icon']; ?>
                                    </div>
                                    <span class="nav-link-text ms-1"><?= $sm['title']; ?></span>
                                    </a>
                        </li>
                    <?php endforeach; ?>

                <?php endforeach; ?>
            </ul>
        </div>
    </aside>
    <main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg ">